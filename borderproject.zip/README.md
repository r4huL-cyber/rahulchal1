# borderproject

This is a minimal Django project that serves your provided HTML as the homepage.

How to run:

1. Create a Python virtual environment and activate it:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the development server on port 6983:
   ```
   python3 manage.py runserver 0.0.0.0:6983
   ```

4. Open your browser at:
   http://<YOUR_SERVER_IP>:6983

Notes:
- DEBUG is True in settings.py for convenience. Change SECRET_KEY and DEBUG for production.
- The project already points templates DIR to archive/templates.
