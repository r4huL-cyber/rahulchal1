from django.shortcuts import render
from django.http import JsonResponse

CHALLENGES = [
    { "question": "The train ticket was issued on 21st September 2025... What day of the week?", "answer": "sunday" },
    { "question": "The destination city is the southernmost capital city of India’s states. Find its three-letter railway station code.", "answer": "tvc" },
    { "question": "The ticket was printed at a junction station hub in the southern railway network. Identify its three-letter code.", "answer": "kpy" },
    { "question": "The smart card used was issued in the zone covering Tamil Nadu and Kerala. Which railway zone?", "answer": "southern" },
    { "question": "Expand the acronym ATVM.", "answer": "machine" },
    { "question": "SAC 996411 covers passenger transport services via which mode?", "answer": "transport" },
    { "question": "The black-and-white pattern ensures authenticity during ticket checking. What is its primary purpose?", "answer": "verification" }
]

def index(request):
    questions = [{ "question": c["question"] } for c in CHALLENGES]
    return render(request, "challenge/index.html", {"challenges": questions})

def check(request):
    idx = int(request.GET.get("idx", -1))
    answer = request.GET.get("answer", "").strip().lower()
    if 0 <= idx < len(CHALLENGES):
        correct = (answer == CHALLENGES[idx]["answer"])
        return JsonResponse({"correct": correct})
    return JsonResponse({"correct": False})
