from django.urls import path
from . import views

app_name = 'osint'
urlpatterns = [
    path('', views.challenge_view, name='challenge'),
    path('check/', views.check_answer, name='check_answer'),
]
