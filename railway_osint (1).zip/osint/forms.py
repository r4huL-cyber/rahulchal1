from django import forms

class AnswerForm(forms.Form):
    index = forms.IntegerField(widget=forms.HiddenInput)
    answer = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'Enter flag...', 'class': 'answer-input'}),
        strip=True,
    )
