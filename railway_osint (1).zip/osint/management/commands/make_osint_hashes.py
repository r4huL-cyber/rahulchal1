from django.core.management.base import BaseCommand
from django.contrib.auth.hashers import make_password
import json

class Command(BaseCommand):
    help = 'Generate osint_hashes.json with hashed answers'

    def add_arguments(self, parser):
        parser.add_argument('--answers', nargs='+', help='List of answers in order')

    def handle(self, *args, **opts):
        questions = [
            "The ticket was purchased on 21/09/2025. What day of the week was that?",
            "What is the three-letter station code for the destination, Thiruvananthapuram?",
            "What is the station code for the printing location?",
            "Which railway zone likely issued the smart card used for payment?",
            "The acronym ATVM stands for Automated Ticket Vending...?",
            "The SAC code 996411 represents passenger transport services by what method?",
            "What is the primary purpose of the QR code on this ticket?"
        ]
        answers = opts['answers']
        if not answers or len(answers) != len(questions):
            self.stderr.write('You must provide exactly %d answers' % len(questions))
            return
        data = []
        for q,a in zip(questions, answers):
            data.append({'question': q, 'hash': make_password(a.strip().lower())})
        with open('osint_hashes.json','w') as f:
            json.dump(data,f,indent=2)
        self.stdout.write(self.style.SUCCESS('osint_hashes.json created.'))
