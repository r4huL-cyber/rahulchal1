from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.contrib.auth.hashers import check_password
from .forms import AnswerForm
import json, os

def load_challenges():
    return getattr(settings, 'OSINT_CHALLENGES', [])

def challenge_view(request):
    challenges = load_challenges()
    solved = request.session.get('osint_solved', [])
    forms = []
    for idx, chal in enumerate(challenges):
        form = AnswerForm(initial={'index': idx})
        is_cleared = idx in solved
        forms.append((idx, chal['question'], form, is_cleared))
    all_solved = len(solved) == len(challenges) and len(challenges) > 0
    flag = settings.OSINT_FLAG if all_solved else None
    return render(request, 'osint/index.html', {
        'forms': forms,
        'all_solved': all_solved,
        'flag': flag,
    })

@require_POST
def check_answer(request):
    form = AnswerForm(request.POST)
    if not form.is_valid():
        messages.error(request, 'Invalid input.')
        return redirect('osint:challenge')

    idx = form.cleaned_data['index']
    answer = form.cleaned_data['answer'].strip().lower()

    challenges = load_challenges()
    if idx < 0 or idx >= len(challenges):
        messages.error(request, 'Invalid challenge index.')
        return redirect('osint:challenge')

    target_hash = challenges[idx]['hash']
    if check_password(answer, target_hash):
        solved = set(request.session.get('osint_solved', []))
        solved.add(idx)
        request.session['osint_solved'] = list(solved)
        messages.success(request, f'Challenge #{idx+1} cleared.')
    else:
        messages.error(request, 'Incorrect — try again.')
    return redirect('osint:challenge')
